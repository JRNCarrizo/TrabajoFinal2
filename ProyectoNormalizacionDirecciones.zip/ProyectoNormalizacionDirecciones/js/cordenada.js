async function buscarCordenada() {

    
   
       
    
            const lat = document.getElementById('lat').value;
            const lon = document.getElementById('lon').value;
    
            // URL de la API de normalización de USIG
            const url = `https://servicios.usig.buenosaires.gob.ar/normalizar/?lng=${lon}&lat=${lat}`;
    
            // Realiza la solicitud a la API con Axios
            axios.get(url)
                .then(response => {
                    // Verifica y muestra el resultado
                    const direccion = response.data.direccion ? response.data.direccion : "No se encontró una dirección.";
                    document.getElementById('resultado').textContent = `Dirección Normalizada: ${direccion}`;
                })
                .catch(error => {
                    // Maneja errores
                    console.error(error);
                    document.getElementById('resultado').textContent = "Ocurrió un error al intentar normalizar la dirección.";
                });
        
    
    

 }