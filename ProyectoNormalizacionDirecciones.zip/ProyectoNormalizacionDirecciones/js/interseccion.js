function interseccion() {
    let calle1 = document.getElementById("calle1").value;
    let calle2 = document.getElementById("calle2").value;

    if (!calle1 || !calle2) {
        alert("Por favor ingrese ambas calles.");
        return;
    }

    // Construcción de la URL
    let url = `https://servicios.usig.buenosaires.gob.ar/normalizar/?direccion=${encodeURIComponent(calle1)}%20y%20${encodeURIComponent(calle2)}`;

    // Mostrar indicador de carga
    document.getElementById("resultado").innerHTML = "Buscando...";

    // Realizar la solicitud a la API
    axios.get(url)
        .then(function(response) {
            // Mostrar la respuesta completa en la consola para inspección
            console.log(response);

            // Verificar si la respuesta contiene el array 'direccionesNormalizadas'
            if (response.data.direccionesNormalizadas && response.data.direccionesNormalizadas.length > 0) {
                // Acceder al primer resultado y mostrar la dirección normalizada
                const resultado = response.data.direccionesNormalizadas[0];
                const direccion = `${resultado.direccion}, ${resultado.nombre_localidad}`;
                document.getElementById("resultado").innerHTML = `Dirección normalizada: ${direccion}`;
            } else {
                document.getElementById("resultado").innerHTML = "No se encontraron resultados para esta intersección.";
            }
        })
        .catch(function(error) {
            console.error("Hubo un error al realizar la solicitud:", error);
            document.getElementById("resultado").innerHTML = "La API no está disponible en este momento. Intenta más tarde.";
        })
    }